//router
// import IndexRouters from "./router/index"
import DefaultRouter from './layouts/dashboard/default'

//scss
import "./assets/scss/hope-ui.scss"
import "./assets/scss/dark.scss"
import "./assets/scss/rtl.scss"
import "./assets/scss/custom.scss"
import "./assets/scss/customizer.scss"

function App() {
  return (
    <div className="App">
      <DefaultRouter />
    </div>
  );
}

export default App;
