import React from 'react'
import Index from '../views/dashboard'
const HorizontalMulti2Router = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default HorizontalMulti2Router
