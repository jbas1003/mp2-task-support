import React from 'react'
import Index from '../views/dashboard'
const HorizontalRouter = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default HorizontalRouter
