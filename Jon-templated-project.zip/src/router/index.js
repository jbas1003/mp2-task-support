import React from 'react'


//router
import { Switch,Route } from 'react-router'
//layoutpages
// import Index from '../views/index'
// import Index from '../views/dashboard/index'
import Default from '../layouts/dashboard/default'
// import Horizontal from '../layouts/dashboard/horizontal'
// import Boxed from '../layouts/dashboard/boxed'
// import DualHorizontal from '../layouts/dashboard/dual-horizontal'
// import DualCompact from '../layouts/dashboard/dual-compact'
// import BoxedFancy from "../layouts/dashboard/boxed-fancy"
import Simple from '../layouts/dashboard/simple'
import RequestForm from '../layouts/dashboard/request-form'
import Kanban from '../views/dashboard/tasks/kanban'


const IndexRouters = () => {
    return (
        <>
            <Switch>
                {/* START: Temporary */}
                {/* INDEX SHOULD BE LOGIN */}
                <Route exact path="/" component={Default}></Route>
                <Route path="/src/views/dashboard/tasks/kanban.js" component={Kanban}></Route>

                {/* END Temporary */}
                
                <Route  path="/auth" component={Simple}></Route>
                <Route  path="/errors" component={Simple}></Route>
                <Route  path="/request-form" component={RequestForm}></Route>
            </Switch>
        </>
    )
}

export default IndexRouters
