import React from 'react'
import Index from '../views/dashboard'

const HorizontalMultiRouter = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default HorizontalMultiRouter
