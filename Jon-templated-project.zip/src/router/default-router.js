import React from 'react'
import Index from '../views/dashboard'
import {Switch,Route} from 'react-router-dom'

import Kanban from '../views/dashboard/tasks/kanban'
import Calendar from '../views/dashboard/tasks/calendar'
import TableData from '../views/dashboard/users/view-users'
// import FullFeaturedCrudGrid from '../views/dashboard/users/view'
// import App from '../views/dashboard/users/view'

//TransitionGroup
import {TransitionGroup,CSSTransition} from "react-transition-group";

const DefaultRouter = () => {
    return (
        <TransitionGroup>
            <CSSTransition classNames="fadein" timeout={300}>
                <Switch>
                    <Route path="/" exact component={Index} />
                    <Route path="/dashboard/tasks/kanban"   exact component={Kanban} />
                    <Route path="/dashboard/tasks/calendar"   exact component={Calendar} />
                    <Route path="/dashboard/users/view-users"   exact component={TableData} />
                    {/* <Route path="/dashboard/users/view-users"   exact component={FullFeaturedCrudGrid} /> */}
                    {/* <Route path="/dashboard/users/view"   exact component={App} /> */}
                </Switch>
            </CSSTransition>
        </TransitionGroup>
    )
}

export default DefaultRouter
