import React from 'react'
import Index from '../views/dashboard'
const BoxedFancyRouter = () => {
    return (
        <div>
            <Index />
        </div>
    )
}

export default BoxedFancyRouter
