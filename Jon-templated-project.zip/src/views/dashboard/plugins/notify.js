import React from 'react'

const Notify = () => {
    return (
        <div>
            
        </div>
    )
}

export default Notify
