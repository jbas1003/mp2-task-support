import React from 'react'

const Dropzone = () => {
    return (
        <div>
            
        </div>
    )
}

export default Dropzone
