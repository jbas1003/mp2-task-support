import React from 'react'

 const Apexchart = () => {
    return (
        <div>
             Apexchart
        </div>
    )
}
export default Apexchart;