import React from 'react'

const UiButton = () => {
    return (
        <div>
            UiButton
        </div>
    )
}
export default UiButton;