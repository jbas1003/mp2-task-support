import React from 'react'

const HorizontalMulti = () => {
    return (
        <div>
            
        </div>
    )
}

export default HorizontalMulti
