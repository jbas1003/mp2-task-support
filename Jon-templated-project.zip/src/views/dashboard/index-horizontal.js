import React from 'react'

const Horizontal = () => {
    return (
        <div>
            
        </div>
    )
}

export default Horizontal
