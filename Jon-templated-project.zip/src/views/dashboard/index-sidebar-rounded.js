import React from 'react'

const SidebarRounded = () => {
    return (
        <div>
            
        </div>
    )
}

export default SidebarRounded
