import React from 'react'

const BoxedFancy = () => {
    return (
        <div>
            BoxedFancy
            <button>click</button>
        </div>
    )
}

export default BoxedFancy
