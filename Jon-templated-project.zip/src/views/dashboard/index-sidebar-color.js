import React from 'react'

const SidebarColor = () => {
    return (
        <div>
            
        </div>
    )
}

export default SidebarColor
