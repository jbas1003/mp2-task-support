import { serverRoutes } from "./constants";

// START: Add to Table Users
export const addUser = (fname, lname, mname, email, uname, pword) => {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var raw = JSON.stringify({
        "firstName": fname,
        "lastName": lname,
        "middleName": mname,
        "email": email,
        "userName": uname,
        "passWord": pword
    });

    var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw
    };
    
    return fetch(serverRoutes.addUser, requestOptions).then(result=>{
        console.log(result)
    })
}

// END: Add to Table Users

// START: tblusers Query All

export const getUsers = (callback) => {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var requestOptions = {
        method: "GET",
        headers: myHeaders,
    };

    getURL(serverRoutes.showUsers, requestOptions)
    async function getURL(url, req){
        const api = await fetch(url)
        const query = await api.json()
        
        // console.log(query)
        callback(query)
    }
}

export const updateUser = (userId, fname, lname, mname, email, uname, pword) => {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var raw = JSON.stringify({
        "userId": userId,
        "firstName": fname,
        "lastName": lname,
        "middleName": mname,
        "email": email,
        "userName": uname,
        "passWord": pword
    });

    var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw
    };
    
    return fetch(serverRoutes.updateUser, requestOptions)
}

export const deleteUser = (userId) => {
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    var raw = JSON.stringify({
        "userId": userId
    });

    var requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw
    };
    
    return fetch(serverRoutes.deleteUser, requestOptions)
}


// END: tblusers Query All