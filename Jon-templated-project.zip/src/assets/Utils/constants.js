export const myApiURL = 'http://localhost:3000';

export const serverRoutes = {
    addUser: myApiURL + '/addUser',
    showUsers: myApiURL + '/showUsers',
    updateUser: myApiURL + '/updateUser',
    deleteUser: myApiURL + '/deleteUser'
}